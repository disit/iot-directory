<?php
/* Snap4City: IoT-Directory
   Copyright (C) 2017 DISIT Lab https://www.disit.org - University of Florence

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA. */
?>


<i id="mobMainMenuBtn" data-shown="false" class="fa fa-navicon"></i>

<div id="mobMainMenuCnt">
    <div id="mobMainMenuPortraitCnt">
        <div class="row">
            <div class="col-xs-12 centerWithFlex" id="mobMainMenuIconCnt">
                <img src="../img/mainMenuIcons/user.ico" />
            </div>
            <div class="col-xs-12 centerWithFlex" id="mobMainMenuUsrCnt">
                <?php echo $_SESSION['loggedUsername']; ?>
            </div>
            <div class="col-xs-12 centerWithFlex" id="mobMainMenuUsrDetCnt">
                <?php echo $_SESSION['loggedRole'] . " | " . $_SESSION['loggedType']; ?>
            </div>
            <div class="col-xs-12 centerWithFlex" id="mobMainMenuUsrLogoutCnt">
                <button type="button" id="mobMainMenuUsrLogoutBtn" class="editDashBtn">logout</button>
            </div>
        </div>
        <hr>
		
		
		<a href="../management/value.php" id="valueLink" class="internalLink moduleLink">
			<div class="col-xs-12 mobMainMenuItemCnt">
				<i class="fa fa-podcast" style="color: #f3cf58"></i>&nbsp;&nbsp;&nbsp; Sensors&amp;Actuators
			</div>
		</a>
	
		<a href="../management/devices.php" id="devicesLink" class="internalLink moduleLink">
			<div class="col-xs-12 mobMainMenuItemCnt">
				<i class="fa fa-microchip" style="color: #33cc33"></i>&nbsp;&nbsp;&nbsp; Devices
			</div>
		</a>
		
	

		 <?php
		if(isset($_SESSION['loggedRole'])&&isset($_SESSION['loggedType']))
        {
            if($_SESSION['loggedRole'] == "ToolAdmin")
            {
		?>
				<a href="../management/contextbroker.php" id="contextBrokerLink" class="internalLink moduleLink">
					<div class="col-xs-12 mobMainMenuItemCnt">
						<i class="fa fa-object-group" style="color: #d84141"></i>&nbsp;&nbsp;&nbsp; Context Brokers
					</div>
				</a>
				
			  
				 <a href="#" id="operationLink" class="dropmenu">
					<div class="col-xs-12 mobMainMenuItemCnt">
						<i class="fa fa-wrench" style="color: #1a8cff"></i>&nbsp;&nbsp;&nbsp; IoT Management  
					</div>
				</a>
				
				<a href="../management/bulkUpdate.php" id="bulkDUpdateLink" class="internalLink moduleLink">
					<div id="bulkDUpdateLink" class="col-xs-12 mobMainMenuItemCnt">
						&nbsp;&nbsp;&nbsp;<i class="fa fa-microchip" style="color: #33cc33"></i>&nbsp;&nbsp;&nbsp; Update Devices  
					</div>
				</a>
				
				<a href="../management/bulkUpdate.php" id="bulkUpdateLink" class="internalLink moduleLink">
					<div id="bulkCBUpdateLink" class="col-xs-12 mobMainMenuItemCnt">
						&nbsp;&nbsp;&nbsp;<i class="fa fa-object-group" style="color: #d84141"></i>&nbsp;&nbsp;&nbsp; Update CBs 
					</div>
				</a>
	
	<?php        
            }
        }
    ?> 

	    
    <?php
        if(isset($_SESSION['loggedRole'])&&isset($_SESSION['loggedType']))
        {
			if(($_SESSION['loggedRole'] == "ToolAdmin") || ($_SESSION['loggedRole'] == "AreaManager"))
            {
    ?>
                <a href="../management/setup.php" id="setupLink" class="internalLink moduleLink">
                    <div class="col-xs-12 mobMainMenuItemCnt">
                        <i class="fa fa-cogs" style="color: #00e6e6"></i>&nbsp;&nbsp;&nbsp;Settings
                    </div>
                </a>
    
    <?php        
            }
        }
    ?> 


	
	
	<a id="usersLink" href="#" class="dropmenu">
		<div  class="col-xs-12 mobMainMenuItemCnt">
			<i class="fa fa-group" style="color: #59c0b9"></i>&nbsp;&nbsp;&nbsp; Local Users
		</div>
	</a> 
	
    <?php
        if(isset($_SESSION['loggedRole'])&&isset($_SESSION['loggedType']))
        {
            if(($_SESSION['loggedRole'] == "ToolAdmin") || ($_SESSION['loggedRole'] == "AreaManager") || ($_SESSION['loggedRole'] == "Manager"))
            {
    ?>
                <a class="internalLink moduleLink" href="../management/account.php" id="accountManagementLink">
                    <div  id="accountLink" class="col-xs-12 mobMainMenuItemCnt">
                        &nbsp;&nbsp;&nbsp;<i class="fa fa-lock" style="color: #ff9933"></i>&nbsp;&nbsp;&nbsp;&nbsp; Account
                    </div>
                </a>
    <?php        
            }
    ?>  
    
    <?php
            if($_SESSION['loggedRole'] == "ToolAdmin")
            {
    ?>

                <a class="internalLink moduleLink" href="../management/users.php" id="link_user_register">
                    <div id="userLink" class="col-xs-12 mobMainMenuItemCnt">
                        &nbsp;&nbsp;&nbsp;<i class="fa fa-user"></i>&nbsp;&nbsp;&nbsp;&nbsp;List of Users
                    </div>
                </a> 
    <?php        
            }
    ?>
    

     
    <?php        
        }
    ?>  
	
      
    </div>
	
	
    
    <div id="mobMainMenuLandCnt">
        <div class="row">
            <div class="col-xs-4 centerWithFlex" id="mobMainMenuUsrCnt">
                <img src="../img/mainMenuIcons/user.ico" />&nbsp;&nbsp;<?php echo $_SESSION['loggedUsername']; ?>
            </div>
            <div class="col-xs-4 centerWithFlex" id="mobMainMenuUsrDetCnt">
                <?php echo $_SESSION['loggedRole'] . " | " . $_SESSION['loggedType']; ?>
            </div>
            <div class="col-xs-4 centerWithFlex" id="mobMainMenuUsrLogoutCnt">
                <button type="button" id="mobMainMenuUsrLogoutBtn" class="editDashBtn">logout</button>
            </div>
        </div>
		
		
		<a href="../management/value.php" id="valueLink" class="internalLink moduleLink">
			<div class="col-xs-4 mobMainMenuItemCnt">
				<i class="fa fa-podcast" style="color: #f3cf58"></i>&nbsp;&nbsp;&nbsp; Sensors&amp;Actuators
			</div>
		</a>
	
		<a href="../management/devices.php" id="devicesLink" class="internalLink moduleLink">
			<<div class="col-xs-4 mobMainMenuItemCnt">
				<i class="fa fa-microchip" style="color: #33cc33"></i>&nbsp;&nbsp;&nbsp; Devices
			</div>
		</a>
		
			

		 <?php
		if(isset($_SESSION['loggedRole'])&&isset($_SESSION['loggedType']))
        {
            if($_SESSION['loggedRole'] == "ToolAdmin")
            {
		?>
				<a href="../management/contextbroker.php" id="contextBrokerLink" class="internalLink moduleLink">
					<div class="col-xs-4 mobMainMenuItemCnt">
						<i class="fa fa-object-group" style="color: #d84141"></i>&nbsp;&nbsp;&nbsp; Context Brokers
					</div>
				</a>
				
			  
				 <a href="#" id="operationLink" class="dropmenu">
					<div class="col-xs-4 mobMainMenuItemCnt">
						<i class="fa fa-wrench" style="color: #1a8cff"></i>&nbsp;&nbsp;&nbsp; IoT Management  
					</div>
				</a>
				
				<a href="../management/bulkUpdate.php" id="bulkDUpdateLink" class="internalLink moduleLink">
					<div id="bulkDUpdateLink" class="col-xs-4 mobMainMenuItemCnt">
						&nbsp;&nbsp;&nbsp;<i class="fa fa-microchip" style="color: #33cc33"></i>&nbsp;&nbsp;&nbsp; Update Devices  
					</div>
				</a>
				
				<a href="../management/bulkUpdate.php" id="bulkUpdateLink" class="internalLink moduleLink">
					<div id="bulkCBUpdateLink" class="col-xs-4 mobMainMenuItemCnt">
						&nbsp;&nbsp;&nbsp;<i class="fa fa-object-group" style="color: #d84141"></i>&nbsp;&nbsp;&nbsp; Update CBs 
					</div>
				</a>
	
	<?php        
            }
        }
    ?> 

	    
    <?php
        if(isset($_SESSION['loggedRole'])&&isset($_SESSION['loggedType']))
        {
			if(($_SESSION['loggedRole'] == "ToolAdmin") || ($_SESSION['loggedRole'] == "AreaManager"))
            {
    ?>
                <a href="../management/setup.php" id="setupLink" class="internalLink moduleLink">
                    <div class="col-xs-4 mobMainMenuItemCnt">
                        <i class="fa fa-cogs" style="color: #00e6e6"></i>&nbsp;&nbsp;&nbsp;Settings
                    </div>
                </a>
    
    <?php        
            }
        }
    ?> 


	
	
	<a id="usersLink" href="#" class="dropmenu">
		<div  class="col-xs-4 mobMainMenuItemCnt">
			<i class="fa fa-group" style="color: #59c0b9"></i>&nbsp;&nbsp;&nbsp; Local Users
		</div>
	</a> 
	
    <?php
        if(isset($_SESSION['loggedRole'])&&isset($_SESSION['loggedType']))
        {
            if(($_SESSION['loggedRole'] == "ToolAdmin") || ($_SESSION['loggedRole'] == "AreaManager") || ($_SESSION['loggedRole'] == "Manager"))
            {
    ?>
                <a class="internalLink moduleLink" href="../management/account.php" id="accountManagementLink">
                    <div  id="accountLink" class="col-xs-4 mobMainMenuItemCnt">
                        &nbsp;&nbsp;&nbsp;<i class="fa fa-lock" style="color: #ff9933"></i>&nbsp;&nbsp;&nbsp;&nbsp; Account
                    </div>
                </a>
    <?php        
            }
    ?>  
    
    <?php
            if($_SESSION['loggedRole'] == "ToolAdmin")
            {
    ?>

                <a class="internalLink moduleLink" href="../management/users.php" id="link_user_register">
                    <div id="userLink" class="col-xs-4 mobMainMenuItemCnt">
                        &nbsp;&nbsp;&nbsp;<i class="fa fa-user"></i>&nbsp;&nbsp;&nbsp;&nbsp;List of Users
                    </div>
                </a> 
    <?php        
            }
    ?>
    

     
    <?php        
        }
    ?>  
		
   

       
    </div>  
</div>

<script type='text/javascript'>
    $(document).ready(function () 
    {
		
		$('#bulkDUpdateLink').hide();
		$('#bulkCBUpdateLink').hide();
		$('#accountLink').hide();
		$('#userLink').hide();
		
        $('#mobMainMenuCnt').css("top", parseInt($('#mobHeaderClaimCnt').height() + $('#headerMenuCnt').height()) + "px");
        
        $( window ).on( "orientationchange", function( event ) {
            if($('#mobMainMenuCnt').is(':visible'))
            {
                if($(window).width() < $(window).height())
                {
                    $('#mobMainMenuPortraitCnt').hide();
                    $('#mobMainMenuLandCnt').show();
                }
                else
                {
                    $('#mobMainMenuLandCnt').hide();
                    $('#mobMainMenuPortraitCnt').show();
                }
            }
        });
        
        $('#mobMainMenuBtn').parent().click(function(){
            if($('#mobMainMenuBtn').attr("data-shown") === "false")
            {
                $('#mobMainMenuCnt').show();
                if($(window).width() < $(window).height())
                {
                    $('#mobMainMenuLandCnt').hide();
                    $('#mobMainMenuPortraitCnt').show();
                }
                else
                {
                    $('#mobMainMenuPortraitCnt').hide();
                    $('#mobMainMenuLandCnt').show();
                }
                
                
                $('#mobMainMenuBtn').attr("data-shown", "true");
                setTimeout(function(){
                    $('#mobMainMenuCnt').css("opacity", "1");
                }, 50);
            }
            else
            {
                
                $('#mobMainMenuCnt').css("opacity", "0");
                $('#mobMainMenuBtn').attr("data-shown", "false");
                setTimeout(function(){
                    $('#mobMainMenuCnt').hide();
                }, 350);
            }
        });
		
		$('#operationLink').click(function(){        
         $('#bulkDUpdateLink').toggle();
		 $('#bulkCBUpdateLink').toggle();
			});
		
		$('#usersLink').click(function(){        
         $('#accountLink').toggle();
		 $('#userLink').toggle();
			});
		
        
        
        $('#mobMainMenuPortraitCnt #mobMainMenuUsrLogoutBtn').click(function(){
            location.href = "logout.php";
       
        });
        
        $('#mobMainMenuLandCnt #mobMainMenuUsrLogoutBtn').click(function(){
            location.href = "logout.php";
        
        });
    });
</script>    

