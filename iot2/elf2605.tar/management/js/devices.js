
var gb_datatypes ="";
var gb_value_units ="";
var gb_value_types = "";
var defaultPolicyValue = [];


var gb_device ="";
var gb_latitude ="";
var gb_longitude = "";

     //   var existingPoolsJson = null;
        // var internalDest = false;
        var tableFirstLoad = true;

//Settaggio dei globals per il file usersManagement.js
 //       setGlobals(admin, existingPoolsJson);
        

 $.ajax({url: "../api/device.php",
         data: {
			 action: 'get_param_values'
			 },
         type: "GET",
         async: true,
         dataType: 'json',
         success: function (mydata)
         {
		   gb_datatypes= mydata["data_type"];
		   gb_value_units= mydata["value_unit"];
		   gb_value_types= mydata["value_type"];		   
         },
		 error: function (mydata)
		 {
		   console.log(JSON.stringify(mydata));
		 }
});
     
        function updateDeviceTimeout()
        {
            $("#editDeviceOkModal").modal('hide');
            setTimeout(function(){
               location.reload();
            }, 500);
        }
        
        function buildMainTable(destroyOld, selected=null)
        {
            if(destroyOld)
            {
                $('#devicesTable').bootstrapTable('destroy');
                tableFirstLoad = true;
				
            }
           
            var statusVisible = true;
            

            if($(window).width() < 992)
            {
     
                statusVisible = false; 
                
            }
			if (selected==null)
			{
			  mydata = {action: "get_all_private_device", token : sessionToken};
			}
			else
			{
			  mydata = {action: "get_subset_device", token : sessionToken, select : selected};
			}
            

            $.ajax({
                url: "../api/device.php",
                data: mydata,
                type: "POST",
                async: true,
                datatype: 'json',
                success: function (data)
                {
					data = data["content"];
					var creatorVisibile = true;
                    var detailView = true;
                    var statusVisibile = true;

                    if($(window).width() < 992)
                    {
                        detailView = false;
                        creatorVisibile = false; 
                        statusVisibile = false;
                    }
				
                    $('#devicesTable').bootstrapTable({
                            columns: [{
									field: 'id',
									title: 'Name',
									filterControl: 'input',
									sortable: true,
									valign: "middle",
									align: "center",
									halign: "center",
									formatter: function(value, row, index)
									{
                                    var maxL = 50;
                                    if($(window).width() < 992)
                                    {
                                        maxL = 15;
                                    }
                                    
                                    if(value !== null)
                                    {
                                        if(value.length > maxL)
                                        {
                                           return value.substr(0, maxL) + " ...";
                                        }
                                        else
                                        {
                                           return value;
                                        } 
                                    }
									
							
                                },
                                cellStyle: function(value, row, index, field) {
                                    var fontSize = "1em"; 
                                    if($(window).width() < 992)
                                    {
                                        fontSize = "0.9em";
                                    }
                                    
                                    
                                    if(index%2 !== 0)
                                    {
                                        return {
                                            classes: null,
                                            css: {
                                                "color": "rgba(51, 64, 69, 1)", 
                                                "font-size": fontSize,
                                                "font-weight": "bold",
                                                "background-color": "rgb(230, 249, 255)",
                                                "border-top": "none"
                                            }
                                        };
                                    }
                                    else
                                    {
                                        return {
                                            classes: null,
                                            css: {
                                                "color": "rgba(51, 64, 69, 1)", 
                                                "font-size": fontSize,
                                                "font-weight": "bold",
                                                "background-color": "white",
                                                "border-top": "none"
                                            }
                                        };
                                    }
                                }
                            }, 
                            {
                                field: 'contextBroker',
								title: 'IOT Broker',
								filterControl: 'select',
								sortable: true,
								valign: "middle",
								align: "center",
								halign: "center",
								// visible: creatorVisibile,
								formatter: function(value, row, index)
                                {
                                    if(value !== null)
									{
										if(value.length > 50)
										{
										   return value.substr(0, 50) + " ...";
										}
										else
										{
										   return value;
										} 
									}
                                },
                                cellStyle: function(value, row, index, field) {
                                    if(index%2 !== 0)
                                    {
                                        return {
                                            classes: null,
                                            css: {
                                                "background-color": "rgb(230, 249, 255)",
                                                "border-top": "none"
                                            }
                                        };
                                    }
                                    else
                                    {
                                        return {
                                            classes: null,
                                            css: {
                                                "background-color": "white",
                                                "border-top": "none"
                                            }
                                        };
                                    }
                                }
                            },
							{
                                field: 'protocol',
								title: 'Protocol',
								filterControl: 'select',
								sortable: true,
								valign: "middle",
								align: "center",
								halign: "center",
								// visible: creatorVisibile,
								formatter: function(value, row, index)
                                {
                                    if(value !== null)
                                    {
                                        if(value.length > 50)
                                        {
                                           return value.substr(0, 50) + " ...";
                                        }
                                        else
                                        {
                                           return value;
                                        } 
                                    }
                                },
                                cellStyle: function(value, row, index, field) {
                                    if(index%2 !== 0)
                                    {
                                        return {
                                            classes: null,
                                            css: {
                                                "background-color": "rgb(230, 249, 255)",
                                                "border-top": "none"
                                            }
                                        };
                                    }
                                    else
                                    {
                                        return {
                                            classes: null,
                                            css: {
                                                "background-color": "white",
                                                "border-top": "none"
                                            }
                                        };
                                    }
                                }
                            },
                            {
                                field: 'format',
								title: 'Format',
								filterControl: 'select',
								sortable: true,
								valign: "middle",
								align: "center",
								halign: "center",
								// visible: creatorVisibile,
								formatter: function(value, row, index)
                                {
                                    if(value !== null)
                                    {
                                        if(value.length > 50)
                                        {
                                           return value.substr(0, 50) + " ...";
                                        }
                                        else
                                        {
                                           return value;
                                        } 
                                    }
                                },
                                cellStyle: function(value, row, index, field) {
                                    if(index%2 !== 0)
                                    {
                                        return {
                                            classes: null,
                                            css: {
                                                "background-color": "rgb(230, 249, 255)",
                                                "border-top": "none"
                                            }
                                        };
                                    }
                                    else
                                    {
                                        return {
                                            classes: null,
                                            css: {
                                                "background-color": "white",
                                                "border-top": "none"
                                            }
                                        };
                                    }
                                }
								
                            },
                            {
                                field: 'devicetype',
								title: 'Device Type',
								filterControl: 'input',
								sortable: true,
								valign: "middle",
								align: "center",
								halign: "center",
								// visible: creatorVisibile,
								formatter: function(value, row, index)
                                {
                                    if(value !== null)
                                    {
                                        if(value.length > 50)
                                        {
                                           return value.substr(0, 50) + " ...";
                                        }
                                        else
                                        {
                                           return value;
                                        } 
                                    }
                                },
                                cellStyle: function(value, row, index, field) {
                                    if(index%2 !== 0)
                                    {
                                        return {
                                            classes: null,
                                            css: {
                                                "background-color": "rgb(230, 249, 255)",
                                                "border-top": "none"
                                            }
                                        };
                                    }
                                    else
                                    {
                                        return {
                                            classes: null,
                                            css: {
                                                "background-color": "white",
                                                "border-top": "none"
                                            }
                                        };
                                    }
                                }
	                       },
							{
                                field: 'visibility',
								title: 'Ownership',
								filterControl: 'select',
								sortable: true,
								valign: "middle",
								align: "center",
								halign: "center",
								// visible: creatorVisibile,
								formatter: function(value, row, index)
                                {
                                    if(value !== null)
                                    {
                                        if(value.length > 50)
                                        {
                                           return value.substr(0, 50) + " ...";
                                        }
                                        else
                                        {
                                           return value;
                                        } 
                                    }
                                },
                                cellStyle: function(value, row, index, field) {
                                    if(index%2 !== 0)
                                    {
                                        return {
                                            classes: null,
                                            css: {
                                                "background-color": "rgb(230, 249, 255)",
                                                "border-top": "none"
                                            }
                                        };
                                    }
                                    else
                                    {
                                        return {
                                            classes: null,
                                            css: {
                                                "background-color": "white",
                                                "border-top": "none"
                                            }
                                        };
                                    }
                                }
                            },
							{
                                title: "Status",
								field: 'status1',
								filterControl: 'select',
								align: "center",
                                valign: "middle",
                                align: "center",
                                halign: "center",
                                formatter: function(value, row, index)
                                {
									//console.log(row.status1);
								// console.log("prop" +row.mandatoryproperties + "value" +row.mandatoryvalues);
								if (row.status1=='active')
								//return '<button type="button" id="active" class="btn btn-success"><span style="font-size:8px; color: white">ACTIVE</span></button>';
								return '<button type="button" id="active" class="activeIoTBtn">ACTIVE</button>';
								else 
								//return '<button type="button" id="iddle" class="btn btn-warning"><span style="font-size:10px; color: white"> IDLE </span></button>';
								return '<button type="button" id="iddle" class="idelIoTBtn">IDDLE</button>';
                                 },
                                cellStyle: function(value, row, index, field) {
                                    if(index%2 !== 0)
                                    {
                                        return {
                                            classes: null,
                                            css: {
												
                                                "background-color": "rgb(230, 249, 255)",
                                                "border-top": "none"
												
                                            }
                                        };
                                    }
                                    else
                                    {
                                        return {
                                            classes: null,
                                            css: {
                                                "background-color": "white",
                                                "border-top": "none"
                                            }
                                        };
                                    }
                                }        
                            },
	
                            {
                                title: "",
                                align: "center",
                                valign: "middle",
                                align: "center",
                                halign: "center",
                                formatter: function(value, row, index)
                                { 
                                    if (row.visibility != "delegated")
									return '<button type="button" class="editDashBtn">edit</button>';
                                },
								cellStyle: function(value, row, index, field) {
                                    if(index%2 !== 0)
                                    {
                                        return {
                                            classes: null,
                                            css: {
                                                "background-color": "rgb(230, 249, 255)",
                                                "border-top": "none"
                                            }
                                        };
                                    }
                                    else
                                    {
                                        return {
                                            classes: null,
                                            css: {
                                                "background-color": "white",
                                                "border-top": "none"
                                            }
                                        };
                                    }
                                }
                            },
                            {
                                title: "",
                                align: "center",
                                valign: "middle",
                                align: "center",
                                halign: "center",
                                formatter: function(value, row, index)
                                {
                                     if (row.visibility != "delegated")
                                    return '<button type="button" class="delDashBtn">del</button>';
                                },
                                cellStyle: function(value, row, index, field) {
                                    if(index%2 !== 0)
                                    {
                                        return {
                                            classes: null,
                                            css: {
                                                "background-color": "rgb(230, 249, 255)",
                                                "border-top": "none"
                                            }
                                        };
                                    }
                                    else
                                    {
                                        return {
                                            classes: null,
                                            css: {
                                                "background-color": "white",
                                                "border-top": "none"
                                            }
                                        };
                                    }
                                }        
                            },
							
							{
                                title: "",
                                align: "center",
                                valign: "middle",
                                align: "center",
                                halign: "center",
                                formatter: function(value, row, index)
                                {
                                    return '<div class="addMapBtn"><i  data-toggle="modal" data-target="#addMapShow" onclick="drawMap(\''+ row.latitude + '\',\'' + row.longitude + '\', \'' + row.id + '\', \'' + row.devicetype + '\', \'' + row.kind + '\', 1)\" class="fa fa-globe"  style=\"font-size:36px; color: #0000ff\"></i></div>';
                                },
                                cellStyle: function(value, row, index, field) {
                                    if(index%2 !== 0)
                                    {
                                        return {
                                            classes: null,
                                            css: {
                                                "background-color": "rgb(230, 249, 255)",
                                                "border-top": "none",
												
                                            }
                                        };
                                    }
                                    else
                                    {
                                        return {
                                            classes: null,
                                            css: {
                                                "background-color": "white",
                                                "border-top": "none"
                                            }
                                        };
                                    }
                                }        
                            }
							],
                            data: data,
                            search: true,
                            pagination: true,
                            pageSize: 10,
							filterControl: true,
                            locale: 'en-US',
                            searchAlign: 'left',
                            uniqueId: "id",
                            striped: false,
                            searchTimeOut: 250,
                            classes: "table table-hover table-no-bordered",
							detailView: detailView,
							detailFormatter: function(index, row, element) {
                            return 'Kind: ' + data[index].kind   + ' | type: ' + data[index].type   + ' | MAC: ' + data[index].macaddress + ' | Model: ' + data[index].model + " | Producer: " + data[index].producer + " | Longitude: " + data[index].longitude + " | Latitude: " + data[index].latitude;
							},
                            rowAttributes: function(row, index){
                            return {
                                "data-id": row.id,
                                "data-devicetype": row.devicetype,
                                "data-kind": row.kind,
                                "data-contextBroker": row.contextBroker,
                                "data-uri": row.uri,
                                "data-protocol": row.protocol,
                                "data-format": row.format,
                                "data-created": row.created,
                                "data-macaddress": row.macaddress,
								"data-model": row.model,
                                "data-producer": row.producer,
                                "data-latitude": row.latitude,
                                "data-longitude": row.longitude,
                                "data-properties": row.properties,
                                "data-attributes": row.attributes,
								"data-visibility": row.visibility,
                                "data-owner": row.owner,
                                "data-frequency": row.frequency
                            };
						},
                            onPostBody: function()
                            {
                                if(tableFirstLoad)
                                {
                                   
								   console.log("Inside the post");
								   tableFirstLoad = false;
									
									var addMapDiv = $('<div id="displayDevicesMap" class="pull-left"><button type="button" class="btn btn-primary btn-round"><span class="glyphicon glyphicon-globe" style="font-size:36px; color: #0000ff"></span></button></div>');
									$('div.fixed-table-toolbar').append(addMapDiv);
									addMapDiv.css("margin-top", "10px");
									addMapDiv.css("margin-left", "150px");
									addMapDiv.find('button.btn btn-primary btn-round').off('hover');
                                    addMapDiv.find('button.btn btn-primary btn-round').hover(function(){
                                        $(this).css('color', '#e37777');
                                       // $(this).css('background', '#ffcc00');
									$(this).parents('tr').find('td').eq(1).css('background', '#ffcc00');
                                    }, 
                                    function(){
                                      $(this).css('background', '#e37777');
                                       //$(this).parents('tr').find('td').eq(1).css('background', $(this).parents('td').css('background'));
                                    });
									
									 
									 $('#displayDevicesMap').off('click');
									 $('#displayDevicesMap').click(function(){
										
										$.ajax({
											url: "../api/device.php",
											data: {
											action: "get_all_device_latlong",
											token : sessionToken
											},
											type: "POST",
											async: true,
											datatype: 'json',
											success: function (data) 
											 {
												
												 if(data["status"] === 'ko')
													{
														  data = data["content"];
													}

												 else (data["status"] === 'ok')
													{
														var data = data["content"];
														var mylat =[];
														var mylong=[];
														
														for (var i=0; i<data.length; i++){
															 mylat.push(data[i].latitude);
															 mylong.push(data[i].longitude);
															}
															
														   $("#addMap1").modal('show');
														    //drawMapAll(mylat, mylong);
                                                            drawMapAll(data);
														}
											 },
											 error: function (data) 
											 {
												 console.log("Ko result: " + data);
											 }
											
										});		
									
									
                                    //  $("#addMap").modal('show');
									//  var  mylat = [45.4350, 43.7845, 43.7812, 43.7856, 43.7756];
									//	var  mylong = [9.2312, 11.2325, 11.2112, 11.2356, 11.2378];
									//  drawMapAll(mylat, mylong);
                                });
									
									
                                   // var addDeviceDiv = $('<div class="pull-right"><i id="addDeviceBtn" data-toggle="modal" data-target="#addDeviceModal" alt="New Device" class="fa fa-plus-square" style="font-size:36px; color: #ffcc00"></i></div>');
									var addDeviceDiv = $('<div class="pull-right"><button id="addDeviceBtn"  class="btn btn-primary">New Device</button></div>');
                                    
                                    $('div.fixed-table-toolbar').append(addDeviceDiv);
                                    addDeviceDiv.css("margin-top", "10px");
									//addDeviceDiv.css("margin-right", "30px");
									//addDeviceDiv.find('i.fa-plus-square').off('hover');
									//addDeviceDiv.find('i.fa-plus-square').hover(function(){
                                    addDeviceDiv.find('button.btn btn-primary').off('hover');
                                    addDeviceDiv.find('button.btn btn-primary').hover(function(){
                                        $(this).css('color', '#e37777');
                                        $(this).css('cursor', 'pointer');
                                    }, 
                                    function(){
                                        $(this).css('color', '#ffcc00');
                                        $(this).css('cursor', 'normal');
                                    });
									
									
									$("#addMyNewDeviceConfirmBtn").off("click");
                                    $("#addMyNewDeviceConfirmBtn").click(function(){
										
										                  
										
									 var nameOpt =  document.getElementById('selectModel').options;
									 var selectednameOpt = document.getElementById('selectModel').selectedIndex;
									 var gb_device =  document.getElementById('inputNameDeviceUser').value;
									 var gb_latitude =  document.getElementById('inputLatitudeDeviceUser').value;
									 var gb_longitude =  document.getElementById('inputLongitudeDeviceUser').value;
									 // $("#addDeviceModal #inputModelDevice").val(nameOpt[selectednameOpt].value);
									 
									 console.log(nameOpt[selectednameOpt].value + " " + gb_device + " " + gb_longitude + " " + gb_latitude);
									 
									 // $("#addDeviceModal #inputNameDevice").val(device);
									 // $("#addDeviceModal #inputLatitudeDevice").val(latitude);
									 // $("#addDeviceModal #inputLongitudeDevice").val(longitude);
									 
									 	$.ajax({
											url: "../api/model.php",
											data: {
											action: "get_model",
											name: nameOpt[selectednameOpt].value 
											},
											type: "GET",
											async: true,
											datatype: 'json',
											success: function (data) 
											 {
												
												 if(data["status"] === 'ko')
													{
														  data = data["content"];
													}

												 else (data["status"] === 'ok')
													{
												
														
														console.log(data);
														console.log(gb_latitude);
														console.log (data.content.kind);
														console.log(data.content.attributes);
														
														var model = data.content.name;
														var type = data.content.devicetype;
														var kind = data.content.kind;
														var producer = data.content.producer;
														//var mac = data.content.mac;
														var frequency = data.content.frequency;
														var contextbroker = data.content.contextbroker;
														var protocol = data.content.protocol;
														var format = data.content.format;
														var attrJSON = data.content.attributes;
														
														/* 
														$('#inputTypeDevice').val(data.content.devicetype);
														$('#selectKindDevice').val(data.content.kind);
														$('#inputProducerDevice').val(data.content.producer);
														$('#inputFrequencyDevice').val(data.content.frequency);
														
														$('#selectContextBroker').val(data.content.contextbroker);
														$('#selectProtocolDevice').val(data.content.protocol);
														$('#selectFormatDevice').val(data.content.format); 
														*/
														
												
														 	 $.ajax({
																 url: "../api/device.php",
																 data:{
																	  action: "insert",   
																	  attributes: attrJSON,
																	  id: gb_device,
																	  type: type,
																	  kind: kind,
																	  latitude: gb_latitude,
																	  longitude: gb_longitude,
																	  mac: "",
																	  model: model,
																	  producer: producer,
																	  visibility: "private",
																	  owner: "marco",
																	  frequency: frequency,
																	  contextbroker : contextbroker,
																	  protocol : protocol,
																	  format : format,
																	  token : sessionToken
																	},
																	 type: "POST",
																	 async: true,
																	 dataType: "json",
																	 timeout: 0,
																	 success: function (data) 
																	 {
																	//	 console.log(mydata);
																    //   res= JSON.parse(mydata); 
																		if(data["status"] === 'ko')
																		{
																			console.log("Error adding Device type");
																			console.log(data);
																			
																	 
																		}			 
																		else (data["status"] === 'ok')
																		{
																			console.log("Added Device");
																			/* 
																			  $('#addDeviceOkMsg').show();
																			 //  alert("Your Private Devices is Added --- " + mydata);
																			  $("#myDeviceForm").load(location.href + "#myDeviceForm");
																			  
																			  $('#inputNameDeviceUser').val("");
																			  $('#inputTypeDeviceUser').val("");
																			  $('#inputLatitudeDeviceUser').val("");
																			  $('#inputLongitudeDeviceUser').val("");
																			  
																			  */
																			
																			
																			
																		} 
																		 
																	 },
																	 error: function (data)
																							{
																		   console.log("Error insert device");  
																		   console.log("Error status -- Ko result: " + JSON.stringify(data));
																	  
																		 
																	 } 
																 });
						 
													
													
													}
											 },
											 error: function (data) 
											 {
												 console.log("Ko result: " + JSON.stringify(data));
											 }
											
										});		
										
									/* 	
                                
									  $("#addDeviceModal").modal('show');
									 // console.log(name);
                                     // $("#addDeviceModalBody").modal('show');
                                      $("#addDeviceLoadingMsg").hide();
                                      $("#addDeviceLoadingIcon").hide();
                                      $("#addDeviceOkMsg").hide();
                                      $("#addDeviceOkIcon").hide();
                                      $("#addDeviceKoMsg").hide();
                                      $("#addDeviceKoIcon").hide();
									   */
									   

                                   });
								
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
									/* This is loading validation when the cursor is on */
								
									
								   
								   $("#addDeviceBtn").off("click");
                                    $("#addDeviceBtn").click(function(){
										
										// console.log(admin);
									  $("#addDeviceModal").modal('show');
                                     // $("#addDeviceModalBody").modal('show');
                                      $("#addDeviceLoadingMsg").hide();
                                      $("#addDeviceLoadingIcon").hide();
                                      $("#addDeviceOkMsg").hide();
                                      $("#addDeviceOkIcon").hide();
                                      $("#addDeviceKoMsg").hide();
                                      $("#addDeviceKoIcon").hide();
									  
									   showAddDeviceModal();

                                   });
								
									
									/* This is a test validation starts on load*/
									
									//$("#addDeviceBtn").off("click");
                                    //$("#addDeviceBtn").click(showAddDeviceModal);
								
                                    $('#devicesTable thead').css("background", "rgba(0, 162, 211, 1)");
                                    $('#devicesTable thead').css("color", "white");
                                    $('#devicesTable thead').css("font-size", "1em");
                                }
                                else
                                {
                                  
                                }

                                //Istruzioni da eseguire comunque
								
								 $('#devicesTable tbody tr').each(function(i){
                                if(i%2 !== 0)
                                {
                                    $(this).find('td').eq(0).css("background-color", "rgb(230, 249, 255)");
                                    $(this).find('td').eq(0).css("border-top", "none");
                                }
                                else
                                {
                                    $(this).find('td').eq(0).css("background-color", "white");
                                    $(this).find('td').eq(0).css("border-top", "none");
                                }
                            });
                                $('#devicesTable').css("border-bottom", "none");
                                $('span.pagination-info').hide();

                                $('#devicesTable tbody button.editDashBtn').off('hover');
                                $('#devicesTable tbody button.editDashBtn').hover(function(){
                                    $(this).css('background', '#ffcc00');
                                    $(this).parents('tr').find('td').eq(1).css('background', '#ffcc00');
                                }, 
                                function(){
                                    $(this).css('background', 'rgb(69, 183, 175)');
                                    $(this).parents('tr').find('td').eq(1).css('background', $(this).parents('td').css('background'));
                                });

                                $('#devicesTable button.editDashBtn').off('click');
                               
                                $('#devicesTable button.editDashBtn').click(function(){
                                    // $("#editDeviceModalUpdating").hide();
									//******Edit Control function call
									
									
							        $("#editDeviceModalBody").show();
									$('#editDeviceModalTabs').show();


                                      $("#editDeviceLoadingMsg").hide();
                                      $("#editDeviceLoadingIcon").hide();
                                      $("#editDeviceOkMsg").hide();
                                      $("#editDeviceOkIcon").hide();
                                      $("#editDeviceKoMsg").hide();
                                      $("#editDeviceKoIcon").hide(); 
									  $("#editDeviceModalFooter").show();
									  $("#editDeviceModal").modal('show');
									  $("#editDeviceModalLabel").html("Edit device - " + $(this).parents('tr').attr("data-id"));
									  
									   
									  var id = $(this).parents('tr').attr('data-id');
									  var contextbroker = $(this).parents('tr').attr('data-contextBroker');
									  var type = $(this).parents('tr').attr('data-devicetype');
									  var kind =  $(this).parents('tr').attr('data-kind');
									  var uri =   $(this).parents('tr').attr('data-uri');
									  var protocol = $(this).parents('tr').attr('data-protocol');
									  var format = $(this).parents('tr').attr('data-format');
									  var macaddress = $(this).parents('tr').attr('data-macaddress');
									  var model = $(this).parents('tr').attr('data-model');
									  var producer = $(this).parents('tr').attr('data-producer');
									  var latitude = $(this).parents('tr').attr('data-latitude');
									  var longitude = $(this).parents('tr').attr('data-longitude');
									  var owner = $(this).parents('tr').attr('data-owner');
									  var frequency = $(this).parents('tr').attr('data-frequency');
									  var visibility = $(this).parents('tr').attr('data-visibility');
									  
									  console.log(id);
									  console.log(contextbroker);
									
									$('#inputNameDeviceM').val(id);
									$('#selectContextBrokerM').val(contextbroker);
									$('#inputTypeDeviceM').val(type);
									$('#selectKindDeviceM').val(kind);
									$('#inputUriDeviceM').val(uri);
									$('#selectProtocolDeviceM').val(protocol);
									$('#selectFormatDeviceM').val(format);
									$('#createdDateDeviceM').val($(this).parents('tr').attr('data-created'));
									$('#inputMacDeviceM').val(macaddress);
									$('#inputModelDeviceM').val(model);
									$('#inputProducerDeviceM').val(producer);
									$('#inputLatitudeDeviceM').val(latitude);															  
									$('#inputLongitudeDeviceM').val(longitude);	
									$('#inputOwnerDeviceM').val(owner);	
									$('#inputFrequencyDeviceM').val(frequency);
									$('#selectVisibilityDeviceM').val(visibility);
									  
									  
									  
									  
											//var x = checkStatus(id, type, contextbroker, kind, protocol, format,  macaddress, model, producer, latitude, longitude, visibility, owner, frequency);
											//console.log(x);
											//$('#inputPropertiesDeviceM').val(x) ;
											
											
											
											//$('#inputPropertiesDeviceM').val($(this).parents('tr').attr('data-properties'));
											
										//	$('#inputAttributesDeviceM').val($(this).parents('tr').attr('data-attributes'));
											showEditDeviceModal();

				$.ajax({
					url: "../api/device.php",
					 data: {
						  action: "get_device_attributes", 
					       id: $(this).parents('tr').attr("data-id"),
					       contextbroker: $(this).parents('tr').attr("data-contextBroker")
						  },
					type: "GET",
					async: true,
					dataType: 'json',
					success: function (mydata) 
					{
					  var row = null;
                      $("#editUserPoolsTable tbody").empty();
					  myattributes=mydata['content'];
					  content="";
					  k=0;
					  while (k < myattributes.length)
					  {
					    // console.log(k); 
					    content += drawAttributeMenu(myattributes[k].value_name, 
						     myattributes[k].data_type, myattributes[k].value_type, myattributes[k].editable, myattributes[k].value_unit, myattributes[k].healthiness_criteria, 
							 myattributes[k].healthiness_value, 'editlistAttributes');
					    k++;
					  }
					  $('#editlistAttributes').html(content);
                     },
                     error: function (data)
                                        {
                                           console.log("Get values pool KO");
                                           console.log(JSON.stringify(data));
                                        }
                                    });
                                });

                                $('#devicesTable button.delDashBtn').off('hover');
                                $('#devicesTable button.delDashBtn').hover(function(){
                                    $(this).css('background', '#ffcc00');
                                    $(this).parents('tr').find('td').eq(1).css('background', '#ffcc00');
                                }, 
                                function(){
                                    $(this).css('background', '#e37777');
                                    $(this).parents('tr').find('td').eq(1).css('background', $(this).parents('td').css('background'));
                                });

                                $('#devicesTable button.delDashBtn').off('click');
                                $('#devicesTable button.delDashBtn').click(function(){
                                    var id = $(this).parents("tr").find("td").eq(1).html();
									var contextBroker = $(this).parents("tr").find("td").eq(2).html();
                                    $("#deleteDeviceModal div.modal-body").html('<div class="modalBodyInnerDiv"><span data-id = "' + id + '" data-contextBroker = "' + contextBroker + '">Do you want to confirm deletion of device <b>' + id + '</b>?</span></div>');
                                    $("#deleteDeviceModal").modal('show');
                                });
                            
									for (var func =0;func < functionality.length; func++)
										{
										  var element = functionality[func];
										  if (element.view=="popup")
										  {
											  if (element[loggedRole]==1)  
											   {   // console.log(element.view + loggedRole + " " + element[loggedRole] + " " + element["class"]); 
												   $(element["class"]).show();
											   }			   
											   else 
											   { 
												  $(element["class"]).hide();
												//  console.log(element.view + loggedRole + " " + element[loggedRole] + " " + element["class"]);
											   }
											}   
										}
							
							
							
							
							}
                        });
                    }
            });
        }
    



    $(document).ready(function () 
    {
		

	//Titolo Default
	if (titolo_default != ""){
		$('#headerTitleCnt').text(titolo_default);
	}
	
	if (access_denied != ""){
		alert('You need to log in with the right credentials before to access to this page!');
	}
	
		///// SHOW FRAME PARAMETER USE/////
		if (nascondi == 'hide'){
			$('#mainMenuCnt').hide();
			$('#title_row').hide();
			$('#mainCnt').removeClass('col-md-10');
			$('#mainCnt').addClass('col-md-12');
		}
		//// SHOW FRAME PARAMETER  ////
		
		$('#sessionExpiringPopup').css("top", parseInt($('body').height() - $('#sessionExpiringPopup').height()) + "px");
        $('#sessionExpiringPopup').css("left", parseInt($('body').width() - $('#sessionExpiringPopup').width()) + "px");
        
        setInterval(function(){
            var now = parseInt(new Date().getTime() / 1000);
            var difference = sessionEndTime - now;
            
            if(difference === 300)
            {
                $('#sessionExpiringPopupTime').html("5 minutes");
                $('#sessionExpiringPopup').show();
                $('#sessionExpiringPopup').css("opacity", "1");
                setTimeout(function(){
                    $('#sessionExpiringPopup').css("opacity", "0");
                    setTimeout(function(){
                        $('#sessionExpiringPopup').hide();
                    }, 1000);
                }, 4000);
            }
            
            if(difference === 120)
            {
                $('#sessionExpiringPopupTime').html("2 minutes");
                $('#sessionExpiringPopup').show();
                $('#sessionExpiringPopup').css("opacity", "1");
                setTimeout(function(){
                    $('#sessionExpiringPopup').css("opacity", "0");
                    setTimeout(function(){
                        $('#sessionExpiringPopup').hide();
                    }, 1000);
                }, 4000);
            }
            
            if((difference > 0)&&(difference <= 60))
            {
                $('#sessionExpiringPopup').show();
                $('#sessionExpiringPopup').css("opacity", "1");
                $('#sessionExpiringPopupTime').html(difference + " seconds");
            }
            
            if(difference <= 0)
            {
                location.href = "logout.php?sessionExpired=true";
            }
        }, 1000);
        
        $('#mainContentCnt').height($('#mainMenuCnt').height() - $('#headerTitleCnt').height());
        
        $(window).resize(function(){
            $('#mainContentCnt').height($('#mainMenuCnt').height() - $('#headerTitleCnt').height());
            if($(window).width() < 992)
            {
                $('#devicesTable').bootstrapTable('hideColumn', 'id');
                $('#devicesTable').bootstrapTable('hideColumn', 'contextBroker');
                //$('#devicesTable').bootstrapTable('hideColumn', 'uri');
                $('#devicesTable').bootstrapTable('hideColumn', 'protocol');
                $('#devicesTable').bootstrapTable('hideColumn', 'format');
                //$('#devicesTable').bootstrapTable('hideColumn', 'type');
            
            }
            else
            {
                $('#devicesTable').bootstrapTable('showColumn', 'id');
                $('#devicesTable').bootstrapTable('showColumn', 'contextBroker');
                //$('#devicesTable').bootstrapTable('showColumn', 'uri');
                $('#devicesTable').bootstrapTable('showColumn', 'protocol');
                $('#devicesTable').bootstrapTable('showColumn', 'format');
                //$('#devicesTable').bootstrapTable('showColumn', 'type');
           
            }
        });
		
		$("#addMyNewDeviceRow").hide();
		
		for (var func =0;func < functionality.length; func++)
		{
		  var element = functionality[func];
		  if (element.view=="view")
		  {
			  if (element[loggedRole]==1)  
			   {   // console.log(loggedRole + " " + element[loggedRole] + " " + element["class"]); 
				   $(element["class"]).show();
			   }			   
			   else 
			   { 
				 $(element["class"]).hide();
				 // console.log($(element.class));
				//  console.log(loggedRole + " " + element[loggedRole] + " " + element["class"]);
			   }
			}   
		}
		
		
		$('#devicesLink .mainMenuItemCnt').addClass("mainMenuItemCntActive");
        $('#mobMainMenuPortraitCnt #devicesLink .mobMainMenuItemCnt').addClass("mainMenuItemCntActive");
        $('#mobMainMenuLandCnt #devicesLink .mobMainMenuItemCnt').addClass("mainMenuItemCntActive");
        
        
        buildMainTable(false);
        
		$("#addMyNewDevice").click(function() {
		
			console.log("add new device");	
			$("#displayAllDeviceRow").hide();
			$("#addMyNewDeviceRow").show();

			$('#inputNameDeviceUser').val("");
			$('#inputTypeDeviceUser').val("");
			$('#inputLatitudeDeviceUser').val("");
			$('#inputLongitudeDeviceUser').val("");
			drawMapUser(43.78, 11.23);
			// showAddDeviceModal();
			
				 
			
		});
		
		$("#allDevice").click(function() {
			
			$("#displayAllDeviceRow").show();
			// $("#addDeviceModal").modal('show');
			$("#addMyNewDeviceRow").hide();
		});
	
		$("#myDevice").click(function() {
			
		 $("#displayAllDeviceRow").show();
		// $("#addDeviceModal").modal('show');
		 $("#addMyNewDeviceRow").hide();
		 
		});
		
								/* add lines related to attributes USER */			
									$("#addAttrBtnUser").off("click");
									$("#addAttrBtnUser").click(function(){
									   console.log("#addAttrBtnUser");							   
									   content = drawAttributeMenuUser("","", "",  'addlistAttributesUser');
									   $('#addlistAttributesUser').append(content);
									});	
									
									$("#attrNameDelbtnUser").off("click");
									$("#attrNameDelbtnUser").on("click", function(){
										console.log("#attrNameDelbtnUser");	
										$(this).parent('tr').remove();
										});	
					
		
		
		
		$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
			var target = $(e.target).attr("href");
			if ((target == '#addGeoPositionTabDevice')) {
				console.log("Elf: Add Device Map");
				var latitude = 43.78; 
				var longitude = 11.23;
				var flag = 0;
				drawMap1(latitude,longitude, flag);
			} else {//nothing
			}
		});


		$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
			var target = $(e.target).attr("href");
			if ((target == '#editGeoPositionTabDevice')) {
				console.log("Elf : EditDeviceMap");
					var latitude = $("#inputLatitudeDeviceM").val(); 
					var longitude = $("#inputLongitudeDeviceM").val();
					var flag = 1;
				drawMap1(latitude,longitude, flag);
			} else {//nothing
			}
		});
		
	


	$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
	var target = $(e.target).attr("href");
	if ((target == '#editStatusTabDevice')) {
		
		var id = document.getElementById('inputNameDeviceM').value;
		var contextbroker = document.getElementById('selectContextBrokerM').value;
		var type = document.getElementById('inputTypeDeviceM').value;
		var kind = document.getElementById('selectKindDeviceM').value;
		var latitude = document.getElementById('inputLatitudeDeviceM').value;
		var longitude = document.getElementById('inputLongitudeDeviceM').value;
		var protocol = document.getElementById('selectProtocolDeviceM').value;
		
			   if (id==null || id=="") { var idNote = ("\n id not specified");} else{idNote = "&#10004;";}
			   if (contextbroker==null || contextbroker=="") {var contextbrokerNote = ("cb not specified");} else{contextbrokerNote = "&#10004;";}
			   if (type==null || type=="") {var typeNote = ("type not specified");} else{typeNote = "&#10004;";}
			   if (!(kind=="sensor" || kind=="actuator")) {var kindNote = ("\n kind not specified");}  else{kindNote = "&#10004;";}
			   if ((latitude < -90 && latitude > 90) || (latitude=="" || latitude==null)) {var latitudeNote = ("\n latitude not correct ");} else{latitudeNote = "&#10004;";}
			   if ((longitude < -180 && longitude > 180) || (longitude=="" || longitude==null)) {var longitudeNote = ("\n longitude not correct ");} else{longitudeNote = "&#10004;";}
			   if (!(protocol=="ngsi" || protocol=="mqtt" || protocol=="amqp")) {var protocolNote = ("protocol not correct ");} else{protocolNote = "&#10004;";}
		
		console.log(id + contextbroker + type + kind + latitude + longitude + protocol);
	
			if ((idNote == "&#10004;") && (contextbrokerNote == "&#10004;") && (typeNote == "&#10004;") && (kindNote == "&#10004;") && (latitudeNote == "&#10004;") && (longitudeNote == "&#10004;") && (protocolNote == "&#10004;")){var statusNote = "<button class=\"btn btn-success btn-round\"></button>";} else{statusNote= "<button class=\"btn btn-danger btn-round\"></button>";}
		
		var x =inputPropertiesDeviceMMsg.innerHTML;
		
		var div = document.createElement("div");
		console.log("IPDMM:" + x);
		
		if (x =="&nbsp;"){
			}
		else{
			inputPropertiesDeviceMMsg.innerHTML="";
		}

		div.innerHTML = ("<div style=\"border:3px solid blue;\" >" +
		"<h2>Device Status</h2>" +
		"<table class=\"table\"><thead><tr><th>Property Status</th><th> checked</th></tr></thead>" +
		"<tbody><tr><td>id</td><td>" + idNote + "</td></tr>" +
		"<tr><td>Contextbroker</td><td>" + contextbrokerNote + "</td></tr>" +
		"<tr><td>Type</td><td>" + typeNote + "</td></tr>" +
		"<tr><td>Kind</td><td>" + kindNote +" </td></tr>" +
		"<tr><td>Protocol</td><td>" + protocolNote + "</td></tr>" +
		"<tr><td>Latitude</td><td>"+ latitudeNote +" </td></tr>" +
		"<tr><td>Longitude</td><td>"+ longitudeNote + "</td></tr>" +
		"<tr><td>Overall Status</td><td>"+ statusNote + "</td></tr>" +
		"</tbody></table></div>");
		inputPropertiesDeviceMMsg.appendChild(div);
		
		} 

	});	
		
        
});  // end of ready-state
	
		
        
	
		
 
		
        $("#addNewDeviceCancelBtn").off("click");
        $("#addNewDeviceCancelBtn").on('click', function(){
            
			  $('#inputNameDevice').val("");
			  $('#inputTypeDevice').val("");
			  $('#selectContextBroker').val("");
			  $('#inputUriDevice').val("");
			  $('#selectProtocolDevice').val("");
			  $('#selectFormatDevice').val("");
			  $('#createdDateDevice').val("");
			  $('#inputMacDevice').val("");
			  $('#inputModelDevice').val("");
			  $('#inputProducerDevice').val("");
			  $('#inputLatitudeDevice').val("");
			  $('#inputLongitudeDevice').val("");
			  $('#addDeviceModal').modal('hide'); 
			  //.hide();
			  location.reload();    								  
			//  $('#addDeviceModalTabs').show();
			//  $('#addDeviceModal div.modalCell').show();
			//  $('#addDeviceModalFooter').show(); 
        });
        
        $("#addDeviceKoBackBtn").off("click");
        $("#addDeviceKoBackBtn").on('click', function(){
            $("#addDeviceKoModal").modal('hide');
            $("#addDeviceModal").modal('show');
        });
        
        $("#addDeviceKoConfirmBtn").off("click");
        $("#addDeviceKoConfirmBtn").on('click', function(){
            $("#addDeviceKoModal").modal('hide');
            $("#addDeviceForm").trigger("reset");
        });
        
        $("#editDeviceKoBackBtn").off("click");
        $("#editDeviceKoBackBtn").on('click', function(){
            $("#editDeviceKoModal").modal('hide');
            $("#editDeviceModal").modal('show');
        });
        
        $("#editDeviceKoConfirmBtn").off("click");
        $("#editDeviceKoConfirmBtn").on('click', function(){
            $("#editDeviceKoModal").modal('hide');
            $("#editDeviceForm").trigger("reset");
        });
        
  	
	$("#selectContextBroker").change(function() {
	
		var index = document.getElementById("selectContextBroker").selectedIndex;
		var opt = document.getElementById("selectContextBroker").options;
		var valCB= opt[index].getAttribute("my_data");
		// console.log("protocol" + JSON.stringify(valCB));
		
		if(valCB ==='ngsi')
		{
			document.getElementById("selectProtocolDevice").value = 'ngsi';
			document.getElementById("selectFormatDevice").value = 'json';
		} 
		else if(valCB ==='mqtt')
		{
			document.getElementById("selectProtocolDevice").value = 'mqtt';
			document.getElementById("selectFormatDevice").value = 'csv';
		} 
		else if (valCB ==='amqp')
		{
			document.getElementById("selectProtocolDevice").value = 'amqp';
			document.getElementById("selectFormatDevice").value = 'csv';
		} 
		else
		{
			//alert("This is a new contextBroker");
			console.log("an error occurred");
		}
		
		
	});
	
	

		
	
	
	/* Related to the Map */
						

function drawMap1(latitude,longitude,flag){	
	var marker;
	
	if (flag ==0){
		var map = L.map('addLatLong').setView([latitude,longitude], 10);
		L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
			attribution: '&copy; <a href="https://openstreetmap.org/copyright">OpenStreetMap</a> contributors'
		}).addTo(map);
		window.node_input_map = map;
		
		
		setTimeout(function(){ map.invalidateSize()}, 400);
		
		//L.marker([latitude,longitude]).addTo(map).bindPopup(latitude + ',' + longitude);
		
			map.on("click", function (e) {
			
			var lat = e.latlng.lat;
			var lng = e.latlng.lng;
				lat = lat.toFixed(4);
				lng = lng.toFixed(4);
				console.log("Check the format:" + lat + " " + lng);
				
				 document.getElementById('inputLatitudeDevice').value = lat;
				 document.getElementById('inputLongitudeDevice').value = lng;
				  addDeviceConditionsArray['inputLatitudeDevice'] = true;
                  addDeviceConditionsArray['inputLongitudeDevice'] = true;
				 if (marker){
					 map.removeLayer(marker);
				 }
				 marker = new L.marker([lat,lng]).addTo(map).bindPopup(lat + ',' + lng);
			
			});
		

	} else if (flag==1){
		
		var map = L.map('editLatLong').setView([latitude,longitude], 10);
		L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
			attribution: '&copy; <a href="https://openstreetmap.org/copyright">OpenStreetMap</a> contributors'
		}).addTo(map);
		window.node_input_map = map;
		//L.marker([latitude,longitude]).addTo(map).bindPopup("Hi DEVICE");
		
		setTimeout(function(){ map.invalidateSize()}, 400);
		
		marker = new L.marker([latitude,longitude]).addTo(map).bindPopup(longitude + ',' + longitude);
	
			map.on("click", function (e) {
				
				var lat = e.latlng.lat;
				var lng = e.latlng.lng;
				lat = lat.toFixed(4);
				lng = lng.toFixed(4);
				console.log("Check the format:" + lat + " " + lng);
				
				document.getElementById('inputLatitudeDeviceM').value = lat;
				document.getElementById('inputLongitudeDeviceM').value = lng;
				 editDeviceConditionsArray['inputLatitudeDeviceM'] = true;
                 editDeviceConditionsArray['inputLongitudeDeviceM'] = true;
				 if (marker){
					 map.removeLayer(marker);
				 }
				 marker = new L.marker([lat,lng]).addTo(map).bindPopup(lat+ ',' + lng);
			
			});
		
	}
		
}

	
 function drawMap(latitude,longitude, id, devicetype, kind, position){ 
   if (position==1)    map = L.map('addDeviceMapModalBodyShow').setView([latitude,longitude], 10);
    else  map = L.map('addDeviceMapModalBody').setView([latitude,longitude], 10);
   L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
   attribution: '&copy; <a href="https://openstreetmap.org/copyright">OpenStreetMap</a> contributors'
  }).addTo(map);
   window.node_input_map = map;
   L.marker([latitude,longitude]).addTo(map).bindPopup(id + ', ' + devicetype + ', ' + kind);
   setTimeout(function(){ map.invalidateSize()}, 400);
  }

  	
 function drawMapUser(latitude,longitude){ 
	var marker;
 		var map = L.map('addDeviceMapModalBodyUser').setView([latitude,longitude], 10);
		L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
			attribution: '&copy; <a href="https://openstreetmap.org/copyright">OpenStreetMap</a> contributors'
		}).addTo(map);
		window.node_input_map = map;
			
		setTimeout(function(){ map.invalidateSize()}, 400);
	
			map.on("click", function (e) {
			
			var lat = e.latlng.lat;
			var lng = e.latlng.lng;
				lat = lat.toFixed(4);
				lng = lng.toFixed(4);
				console.log("Check the format:" + lat + " " + lng);
				
				 document.getElementById('inputLatitudeDeviceUser').value = lat;
				 document.getElementById('inputLongitudeDeviceUser').value = lng;
				 
				 if (marker){
					 map.removeLayer(marker);
				 }
				 marker = new L.marker([lat,lng]).addTo(map).bindPopup(lat + ',' + lng);
			
			});
  
  }


	

	

