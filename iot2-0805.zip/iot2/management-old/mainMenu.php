
<?php
/* Dashboard Builder.
   Copyright (C) 2016 DISIT Lab https://www.disit.org - University of Florence

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA. */
   include('../config.php');
   include('process-form.php'); 
?>

<div class="hidden-xs hidden-sm col-md-2" id="mainMenuCnt">
    <div id="headerClaimCnt" class="col-md-12 centerWithFlex">Snap4City</div>
    <div class="col-md-12 mainMenuUsrCnt">
        <div class="row">
            <div class="col-md-12 centerWithFlex" id="mainMenuIconCnt">
                <img src="../img/mainMenuIcons/user.ico" />
            </div>
            <div class="col-md-12 centerWithFlex" id="mainMenuUsrCnt">
                <?php echo $_SESSION['loggedUsername']; ?>
            </div>
            <div class="col-md-12 centerWithFlex" id="mainMenuUsrDetCnt">
                <?php echo $_SESSION['loggedRole'] . " | " . $_SESSION['loggedType']; ?>
            </div>
            <div class="col-md-12 centerWithFlex" id="mainMenuUsrLogoutCnt">
                Logout
            </div>
        </div>
    </div>
    

	
	<a href="../management/value.php" id="valueLink" class="internalLink moduleLink">
        <div class="col-md-12 mainMenuItemCnt">
            <i class="fa fa-podcast" style="color: #f3cf58"></i>&nbsp;&nbsp;&nbsp; Sensors&amp;Actuators
        </div>
    </a>
	
	 <a href="../management/devices.php" id="devicesLink" class="internalLink moduleLink">
        <div class="col-md-12 mainMenuItemCnt">
            <i class="fa fa-microchip" style="color: #33cc33"></i>&nbsp;&nbsp;&nbsp; Devices
        </div>
    </a>
	
	<a href="../management/contextbroker.php" id="contextBrokerLink" class="internalLink moduleLink">
        <div class="col-md-12 mainMenuItemCnt">
            <i class="fa fa-object-group" style="color: #d84141"></i>&nbsp;&nbsp;&nbsp; Context Brokers
        </div>
    </a>
	
  
	 <a href="#" id="operationLink" class="dropmenu">
        <div class="col-md-12 mainMenuItemCnt">
            <i class="fa fa-wrench" style="color: #1a8cff"></i>&nbsp;&nbsp;&nbsp; IoT Management  
        </div>
    </a>
	
	<a href="../management/bulkUpdate.php" id="bulkDUpdateLink" class="internalLink moduleLink">
		<div id="bulkDUpdateLink" class="col-md-12 mainMenuItemCnt">
			&nbsp;&nbsp;&nbsp;<i class="fa fa-microchip" style="color: #33cc33"></i>&nbsp;&nbsp;&nbsp; Update Devices  
		</div>
	</a>
	
	<a href="../management/bulkUpdate.php" id="bulkUpdateLink" class="internalLink moduleLink">
		<div id="bulkCBUpdateLink" class="col-md-12 mainMenuItemCnt">
			&nbsp;&nbsp;&nbsp;<i class="fa fa-object-group" style="color: #d84141"></i>&nbsp;&nbsp;&nbsp; Update CBs 
		</div>
	</a>
	
	
	    
    <?php
        if(isset($_SESSION['loggedRole'])&&isset($_SESSION['loggedType']))
        {
            if($_SESSION['loggedRole'] == "ToolAdmin")
            {
    ?>
                <a href="../management/setup.php" id="setupLink" class="internalLink moduleLink">
                    <div class="col-md-12 mainMenuItemCnt">
                        <i class="fa fa-cogs" style="color: #00e6e6"></i>&nbsp;&nbsp;&nbsp;Settings
                    </div>
                </a>
    
    <?php        
            }
        }
    ?> 


	
	
	<a id="usersLink" href="#" class="dropmenu">
		<div  class="col-md-12 mainMenuItemCnt">
			<i class="fa fa-group" style="color: #59c0b9"></i>&nbsp;&nbsp;&nbsp; Local Users
		</div>
	</a> 
	
    <?php
        if(isset($_SESSION['loggedRole'])&&isset($_SESSION['loggedType']))
        {
            if($_SESSION['loggedType'] == "local")
            {
    ?>
                <a class="internalLink moduleLink" href="../management/account.php" id="accountManagementLink">
                    <div  id="accountLink" class="col-md-12 mainMenuItemCnt">
                        &nbsp;&nbsp;&nbsp;<i class="fa fa-lock" style="color: #ff9933"></i>&nbsp;&nbsp;&nbsp;&nbsp; Account
                    </div>
                </a>
    <?php        
            }
    ?>  
    
    <?php
            if($_SESSION['loggedRole'] == "ToolAdmin")
            {
    ?>

                <a class="internalLink moduleLink" href="../management/users.php" id="link_user_register">
                    <div id="userLink" class="col-md-12 mainMenuItemCnt">
                        &nbsp;&nbsp;&nbsp;<i class="fa fa-user"></i>&nbsp;&nbsp;&nbsp;&nbsp;List of Users
                    </div>
                </a> 
    <?php        
            }
    ?>
    

     
    <?php        
        }
    ?>    
       
</div>

<script type='text/javascript'>
    $(document).ready(function () 
    {
		
		$('#bulkDUpdateLink').hide();
		$('#bulkCBUpdateLink').hide();
		$('#accountLink').hide();
		$('#userLink').hide();
		
        $('div.mainMenuUsrCnt').hover(function(){
            $(this).css("background", "rgba(0, 162, 211, 1)");
            $(this).css("cursor", "pointer");
            $('#mainMenuUsrDetCnt').hide();
            $('#mainMenuUsrLogoutCnt').show();
        }, function(){
            $(this).css("background", "transparent");
            $(this).css("cursor", "normal");
            $('#mainMenuUsrLogoutCnt').hide();
            $('#mainMenuUsrDetCnt').show();
        });
		
		
		$('#operationLink').click(function(){        
         $('#bulkDUpdateLink').toggle();
		 $('#bulkCBUpdateLink').toggle();
			});
		
		$('#usersLink').click(function(){        
         $('#accountLink').toggle();
		 $('#userLink').toggle();
			});
		
        
        $('div.mainMenuUsrCnt').click(function(){
            location.href = "logout.php";
            /*$.ajax({
                url: "iframeProxy.php",
                action: "notificatorRemoteLogout",
                async: true,
                success: function()
                {

                },
                error: function(errorData)
                {
                    console.log("Remote logout from Notificator failed");
                    console.log(JSON.stringify(errorData));
                },
                complete: function()
                {
                    location.href = "logout.php";
                }
            });*/
        });
    });
</script>    


