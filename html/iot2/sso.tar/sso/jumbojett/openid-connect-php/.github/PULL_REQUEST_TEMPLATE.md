**List of common tasks a pull request require complete**
- [ ] Changelog entry is added or the pull request don't alter library's functionality
