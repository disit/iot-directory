var alarmTypes = {
   flood : {
      desc: "Flood",
      icon: "flood.png",
      mapIconLow: "floodMapLow.png",
      mapIconMed: "floodMapMed.png",
      mapIconHigh: "floodMapHigh.png"
   },
   others : {
      desc: "Others",
      icon: "alarm.png",
      mapIconLow: "alarmMapLow.png",
      mapIconMed: "alarmMapMed.png",
      mapIconHigh: "alarmMapHigh.png"
   }
};