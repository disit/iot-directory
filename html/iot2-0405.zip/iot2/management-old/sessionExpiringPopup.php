<div id="sessionExpiringPopup">
    <div class="row">
        <div class="col-xs-12 centerWithFlex" id="sessionExpiringPopupIcon">
            <i class="fa fa-exclamation-triangle"></i>
        </div>
    </div>
    <div class="row">
        <div class="col-xs-12 centerWithFlex" id="sessionExpiringPopupMsg">
            Session will expire in
        </div>
    </div>  
    <div class="row">
        <div class="col-xs-12 centerWithFlex" id="sessionExpiringPopupTime">
        </div>
    </div>
</div>

