<?php

/* Dashboard Builder.
   Copyright (C) 2017 DISIT Lab https://www.disit.org - University of Florence

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA. */

   include '../config.php';
   
   //Altrimenti restituisce in output le warning
   error_reporting(E_ERROR | E_NOTICE);
   
//   session_start(); 
   $link = mysqli_connect($host, $username, $password);
   mysqli_select_db($link, $dbname);

   
   	/* ****FUNCTIONS FOR THE REGISTRATION OF A DEVICE IN THE CONTEXT BROKER AND IN THE KNOWLEDGE BASE ******  */
	
	function delete_ngsi($uri, $name, $contextbroker, $ip, $port)
	{
	   $result = "Ok";
	   $msg_orion=array();
      
	  $msg_orion["id"]=     $name; 
      $msg_orion["uri"]=   $uri;
         
      // echo "stefano ".json_encode($msg_orion);
	
	  $url_orion="http://$ip:$port/v2/entities/$name";  

	  // echo $url_orion;
     /* TO BE FIXED 
      try
         {
			// Setup cURL
			$ch = curl_init($url_orion);
			$authToken = 'OAuth 2.0 token here';
			curl_setopt_array($ch, array(
    			CURLOPT_POST => TRUE,
    			CURLOPT_RETURNTRANSFER => TRUE,
    			CURLOPT_HTTPHEADER => array(
					'Authorization: '.$authToken,
					'Content-Type: application/json'),
				CURLOPT_POSTFIELDS => json_encode($msg_orion)
		    ));

		    // Send the request
		    $response_orion = curl_exec($ch);

		    // Check for errors
		    if($response_orion === FALSE){
    			die(curl_error($ch));
			}

		    // Decode the response
		    $responseData = json_decode($response_orion, TRUE);

		    // Print the date from the response
		    echo $responseData['published'];
            }
              catch (Exception $ex) 
            {
		      $result="errore"; echo $ex;
            }
            return $result; */
            return "Ok";			
	}
	
	function delete_mqtt($uri, $name, $contextbroker, $ip, $port)
	{
	  return "Ok";
	}
	
	function delete_amqp($uri, $name, $contextbroker, $ip, $port)
	{
	  return "Ok";
	}
	
	function deleteKB($link, $name) // next version include $contextbroker
   {  
		$result="Ok";
		$q1 = "SELECT d.uri, c.ip, c.port, c.name, c.protocol FROM devices d JOIN contextbroker c ON (d.contextbroker=c.name) WHERE d.name = '$name'";
		$r1 = mysqli_query($link, $q1);
		//echo $q1; 
		
		if($r1) 
		{
			$row = mysqli_fetch_assoc($r1);
			$ip = $row['ip'];
			$port = $row['port'];
			$uri = $row['uri'];
			$contextbroker = $row['name'];
			$protocol = $row['protocol'];
			
		} 
		else
		{
			$result = "errore";
		}
     
	 if ($result!="errore") 
     {    
      /* msg for the Knowledge base + registration on the KB */
      $msg=array();
      $msg["id"]=     $name;
      $msg["uri"]=   $uri;
     /* to be fixed 
      try
       {
         $url="http://www.disit.org/ServiceMap/api/v1/iot/insert";
         $options = array(
                  'http' => array(
                          'header'  => "Content-Type: application/json",
                          'header'  => "Access-Control-Allow-Origin: *",
                          'method'  => 'POST',
			  'content' => json_encode($msg),
                          'timeout' => 30
                  )
            );
         $context  = stream_context_create($options);
         $result = @file_get_contents($url, false, $context);
     } 
     catch (Exception $ex) 
      {
		$result="errore"; echo $ex; 
	 } */
	 /* selection of ip and port of the context broker for registration of the channel */
     }
	 	
    /* deletion of the device from the corresponding context broker */
    if ($result!="errore") 
     {
     // echo 	 $protocol;
     switch ($protocol)
     {
	   case "ngsi": 
	         $result = delete_ngsi($uri, $name, $contextbroker, $ip, $port);
		     break;
       case "mqtt":
	        $result = delete_mqtt($uri, $name, $contextbroker, $ip, $port);
		     break;
		case "amqp":	  
			$result = delete_amqp($uri, $name, $contextbroker, $ip, $port);
		     break;	 
	 }	 
  	}
	return $result;	
   } // end of function deleteKB	 
   
   
   if(!$link->set_charset("utf8")) 
   {
       die();
   }

  // if(isset($_SESSION['loggedRole']))
   if (true)
   {
      $name = $_POST['name'];
      $res=deleteKB($link, $name);
		   
//      $beginTransactionResult = mysqli_begin_transaction($link, MYSQLI_TRANS_START_READ_WRITE);
      
	  if ($res=="Ok")
	  {
       $query = "DELETE FROM devices WHERE name = '$name'";
       $result = mysqli_query($link, $query);
	   // echo $query;

       if($result)
       {
       //      $commit = mysqli_commit($link);
             mysqli_close($link);
             echo 1;
       }
       else
       {
      //       $rollbackResult = mysqli_rollback($link);
             mysqli_close($link);
             echo 0;
       }
	  }else {echo 0;} 
   }
